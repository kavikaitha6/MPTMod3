package com.cg.service;

import java.util.List;

import com.cg.bean.AccountBean;
import com.cg.bean.TransactionBean;
import com.cg.exception.BookingException;

public interface IBankService 
{
	int inserttransDetails(TransactionBean transactionBean) throws BookingException;
	
	AccountBean selectConsumerDetails(String custName) throws BookingException;
	List<AccountBean> dispAccount(String custName) throws BookingException;
}
