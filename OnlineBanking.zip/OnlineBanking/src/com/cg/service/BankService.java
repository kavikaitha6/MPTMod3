package com.cg.service;

import java.util.List;

import com.cg.bean.AccountBean;
import com.cg.bean.TransactionBean;
import com.cg.dao.BankDao;
import com.cg.exception.BookingException;


public class BankService implements IBankService
{
BankDao dao=new BankDao();
	
	
	
	public BankService(BankDao dao) {
	super();
	this.dao = dao;
}

	public BankService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int inserttransDetails(TransactionBean transactionBean)
			throws BookingException {
		
		return dao.inserttransDetails(transactionBean);
	}

	@Override
	public List<AccountBean> dispAccount(String custName) throws BookingException {
		// TODO Auto-generated method stub
		return dao.dispAccount(custName);
	}

	@Override
	public AccountBean selectConsumerDetails(String custName)
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.selectConsumerDetails(custName);
	}
	
}
