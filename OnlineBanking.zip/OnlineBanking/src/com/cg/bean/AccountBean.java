package com.cg.bean;

public class AccountBean
{
String custName;
String accNum;
String accType;
String accLoc;
float balance;
public String getCustName() {
	return custName;
}
public void setCustName(String custName) {
	this.custName = custName;
}
public String getAccNum() {
	return accNum;
}
public void setAccNum(String accNum) {
	this.accNum = accNum;
}
public String getAccType() {
	return accType;
}
public void setAccType(String accType) {
	this.accType = accType;
}
public String getAccLoc() {
	return accLoc;
}
public void setAccLoc(String accLoc) {
	this.accLoc = accLoc;
}
public float getBalance() {
	return balance;
}
public void setBalance(float balance) {
	this.balance = balance;
}
public AccountBean(String custName, String accNum, String accType,
		String accLoc, float balance) {
	super();
	this.custName = custName;
	this.accNum = accNum;
	this.accType = accType;
	this.accLoc = accLoc;
	this.balance = balance;
}
public AccountBean() {
	super();
	
}


}
