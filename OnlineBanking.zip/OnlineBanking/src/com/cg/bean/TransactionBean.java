package com.cg.bean;

import java.sql.Date;

public class TransactionBean 
{
long transactionId;
String transDescr;
float transAmount;
Date transDate;
String accNum;


public TransactionBean() {
	super();
	
}

public TransactionBean(long transactionId, String transDescr,
		float transAmount, Date transDate, String accNum) {
	super();
	this.transactionId = transactionId;
	this.transDescr = transDescr;
	this.transAmount = transAmount;
	this.transDate = transDate;
	this.accNum = accNum;
}
public long getTransactionId() {
	return transactionId;
}
public void setTransactionId(long transactionId) {
	this.transactionId = transactionId;
}
public String getTransDescr() {
	transDescr="ATM debit";
	return transDescr;
}
public void setTransDescr(String transDescr) {
	this.transDescr = transDescr;
}
public float getTransAmount() {
	return transAmount;
}
public void setTransAmount(float transAmount) {
	this.transAmount = transAmount;
}
public Date getTransDate() {
	return transDate;
}
public void setTransDate(Date transDate) {
	this.transDate = transDate;
}
public String getAccNum() {
	return accNum;
}
public void setAccNum(String accNum) {
	this.accNum = accNum;
}

}
