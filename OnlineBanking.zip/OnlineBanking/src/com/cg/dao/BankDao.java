package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.AccountBean;
import com.cg.bean.TransactionBean;
import com.cg.exception.BookingException;
import com.cg.utility.DBUtil;

public class BankDao implements IBankDao
{

	TransactionBean transactionBean;
	@Override
	public int inserttransDetails(TransactionBean transactionBean1) throws BookingException {
		// TODO Auto-generated method stub
		int status=0;
		int transId=0;
		Connection con=DBUtil.createConnection();
		PreparedStatement pst=null;

		String sql=new String("INSERT INTO transaction_details VALUES(transaction_id_seq.NEXTVAL,?,?,sysdate,?)");
		try{

			
			pst= con.prepareStatement(sql);
		
			pst.setString(1, transactionBean1.getTransDescr());
			pst.setFloat(2, transactionBean1.getTransAmount());
			pst.setString(3, transactionBean1.getAccNum());

			status=pst.executeUpdate();
			
			if(status==1)
			{
				Statement s=con.createStatement() ;
				 ResultSet rs=s.executeQuery("select transaction_id_seq.currval from dual");
				 if(rs.next())
					 transId=rs.getInt(1);
			}
		}

		catch(SQLException se){

			throw new BookingException("Record is not inserted");
		}
//		finally{
//			try{
//				DBUtil.closeConnection();	
//			}catch(SQLException se){
//				throw new BookingException("Problems in closing connection");	
//			}
//		}
		return transId;
	}

	
	
	
	@Override
	public List<AccountBean> dispAccount(String custName) throws BookingException {
		// TODO Auto-generated method stub
//displays Account summary
		
		int status=0;
		
		ArrayList<AccountBean> list= new ArrayList<>();
		String sql="SELECT * FROM account_details where customer_name=?";
		try {
			Connection con= DBUtil.createConnection();
			PreparedStatement st= con.prepareStatement(sql);
			st.setString(1,custName);
			ResultSet rs= st.executeQuery();
			
			while(rs.next()){

				AccountBean bill= new AccountBean();
				bill.setAccNum(rs.getString(1));
				bill.setCustName(rs.getString(2));

				bill.setAccType(rs.getString(3));
				bill.setAccLoc(rs.getString(4));
				bill.setBalance(rs.getLong(5));
				
				list.add(bill);
				status=status++;
			
			}
			

		} catch (SQLException e) {

			throw new BookingException(e.getMessage());
		}
		return list;
		
	}




	@Override
	public AccountBean selectConsumerDetails(String custName)
			throws BookingException {
		// TODO Auto-generated method stub
		AccountBean customer=new AccountBean();
		Connection con=DBUtil.createConnection();
		String sql="select * from account_details where customer_name=?";
		try{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, custName);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				customer.setAccNum(rs.getString(1));
				customer.setCustName(rs.getString(2));
				customer.setAccType(rs.getString(3));
				customer.setAccLoc(rs.getString(4));
				customer.setBalance(rs.getFloat(5));
			}
		}catch(SQLException e){
			throw new BookingException(e.getMessage());

		}
		return customer;
		
		
		
		
		
	}



	
	
	

}
