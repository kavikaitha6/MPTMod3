package com.cg.dao;

import java.util.List;

import com.cg.bean.AccountBean;
import com.cg.bean.TransactionBean;
import com.cg.exception.BookingException;

public interface IBankDao
{
int inserttransDetails(TransactionBean transactionBean) throws BookingException;
List<AccountBean> dispAccount(String custName) throws BookingException;
AccountBean selectConsumerDetails(String custName) throws BookingException;

}
