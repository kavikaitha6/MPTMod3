package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.AccountBean;
import com.cg.bean.TransactionBean;
import com.cg.exception.BookingException;
import com.cg.service.BankService;

@WebServlet("/BankController")
public class BankController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BankService service;
	public BankController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//TransactionBean transactionBean= new TransactionBean();
		AccountBean accountBean=new AccountBean();

		String action= request.getParameter("action");


		switch(action)
		{

		case "1" :
			String custName= request.getParameter("custName");
			service=new BankService();
			List<AccountBean>  list=new ArrayList<AccountBean>();


			try {
				list= service.dispAccount(custName);

				request.setAttribute("list",list);
				RequestDispatcher rd=request.getRequestDispatcher("AccountInfo.jsp");
				rd.forward(request, response);

			} catch (BookingException e) {

				request.setAttribute("Error",e.getMessage());
				RequestDispatcher rd=request.getRequestDispatcher("CustomerError.jsp");
				rd.forward(request, response);
			}
			break;
		case "2":
			
			  String accNum=(request.getParameter("accNum"));
			  request.setAttribute("accNum",accNum);
			  RequestDispatcher rd=request.getRequestDispatcher("DebitAmount.jsp");
			  rd.forward(request, response);
			 
			break;
		case "3" :
//			String amount=request.getParameter("amount");
//			String accNum1=request.getParameter("accNum");
//			request.setAttribute("amount", amount);
//			request.setAttribute("accNum", accNum1);
//			rd= request.getRequestDispatcher("TransactionSuccess.jsp");
//			rd.forward(request, response);
//			break;

			int status=0;
			TransactionBean transactionBean=new TransactionBean();
			float amount=Float.parseFloat(request.getParameter("transAmount"));
			String accNum1=request.getParameter("accNum");
			transactionBean.setTransAmount(amount);
			transactionBean.setAccNum(accNum1);
			service=new BankService();
			try 
			{
				status=service.inserttransDetails(transactionBean);
				request.setAttribute("transactionDto", transactionBean);
				RequestDispatcher rd1=request.getRequestDispatcher("TransactionSuccess.jsp");
				rd1.forward(request, response);
			} 
			catch (BookingException e)
			{
				request.setAttribute("Error", e.getMessage());	
				RequestDispatcher rd1=request.getRequestDispatcher("CustomerError.jsp");
				rd1.forward(request, response);
			}
			
			
			break;
		
		}

	}

}














